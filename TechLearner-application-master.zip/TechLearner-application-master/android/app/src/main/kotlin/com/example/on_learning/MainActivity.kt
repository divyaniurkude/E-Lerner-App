package com.example.on_learning

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
